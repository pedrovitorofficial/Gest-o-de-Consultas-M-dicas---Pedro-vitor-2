from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

def cadastro_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save() # O Django salva a senha criptografada automaticamente
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'usuarios/cadastro.html', {'form': form})

def home_view(request):
    # Esta view só será acessível se o usuário estiver logado.
    # A proteção de rota será adicionada nas URLs.
    return render(request, 'usuarios/home.html')