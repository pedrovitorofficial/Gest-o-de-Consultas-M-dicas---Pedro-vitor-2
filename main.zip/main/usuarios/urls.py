from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.decorators import login_required
from .views import cadastro_view, home_view

urlpatterns = [
    path('login/', LoginView.as_view(
        template_name='usuarios/login.html',
        redirect_authenticated_user=True # Redireciona se já estiver logado
    ), name='login'),

    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),

    path('cadastro/', cadastro_view, name='cadastro'),

    # A função login_required protege a rota, exigindo que o usuário esteja logado
    path('', login_required(home_view, login_url='login'), name='home'),
]